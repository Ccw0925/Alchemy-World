<?php
	include('database.php');
	$element1 = $_POST['postElement1'];
	$element2 = $_POST['postElement2'];
	$data = "none";
	$finalElement = "none";
	$description = "";
	$name = "";
	$found = "No";
	$count = 0;
	$sql = "SELECT ID, Name, Description, Image_name FROM elements INNER JOIN combinations on elements.ID=combinations.Final_ID WHERE (element1_id='".$element1."' and Element2_ID='".$element2."') or (Element1_ID='".$element2."' and Element2_ID='".$element1."');";
	$result = $conn->query($sql);
	
	if($result->num_rows > 0) {
		while($row = $result->fetch_assoc()) {
			$finalElement = $row['ID'];
			$name = $row['Name'];
			$description = $row['Description'];
			$data = $row['Image_name'];
		}
	}
	
	$sql = "SELECT Found FROM elements WHERE ID='".$finalElement."';";
	
	$result = $conn->query($sql);
	
	if($result->num_rows > 0) {
		while($row = $result->fetch_assoc()) {
			$found = $row['Found'];
		}
	}
	
	if($data!="none"){
		$sql = "UPDATE elements SET Found='Yes' WHERE ID='".$finalElement."';";
		$conn->query($sql);		
	}
	
	$sql = "SELECT count(*) FROM elements WHERE Found='Yes';";
	
	$result = $conn->query($sql);
	
	if($result->num_rows > 0) {
		while($row = $result->fetch_assoc()) {
			$count = $row['count(*)'];
		}
	}
	
	echo json_encode(array($data, $name, $description, $found, $finalElement, $count));
?>