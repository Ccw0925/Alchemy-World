<?php
	include('database.php');
	$ID = "";
	$element1_ID = "";
	$element2_ID = "";
	$element1_Name = "";
	$image_Name1 = "";
	$element2_Name = "";
	$image_Name2 = "";
	
	$sql = "SELECT * FROM elements WHERE found='No' LIMIT 1";
	$result = $conn->query($sql);
	
	if($result->num_rows > 0) {
		while($row = $result->fetch_assoc()) {
			$ID = $row['ID'];
		}
	}
	
	$sql = "SELECT element1_ID, element2_ID from combinations WHERE final_id='".$ID."';";
	$result = $conn->query($sql);
	
	if($result->num_rows > 0) {
		while($row = $result->fetch_assoc()) {
			$element1_ID = $row['element1_ID'];
			$element2_ID = $row['element2_ID'];
		}
	}
	
	$sql = "SELECT image_name, name from elements where id='".$element1_ID."';";
	$result = $conn->query($sql);
	
	if($result->num_rows > 0) {
		while($row = $result->fetch_assoc()) {
			$element1_Name = $row['name'];
			$image_Name1 = $row['image_name'];
		}
	}
	
	$sql = "SELECT image_name, name from elements where id='".$element2_ID."';";
	$result = $conn->query($sql);
	
	if($result->num_rows > 0) {
		while($row = $result->fetch_assoc()) {
			$element2_Name = $row['name'];
			$image_Name2 = $row['image_name'];
		}
	}
	
	echo json_encode(array($element1_Name, $image_Name1, $element2_Name, $image_Name2));
?>