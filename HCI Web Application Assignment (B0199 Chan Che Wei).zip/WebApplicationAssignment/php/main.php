<html lang="en" id="mainHtml">
	<head>
		<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
	<script
	  src="https://code.jquery.com/jquery-3.4.1.js"
	  integrity="sha256-WpOohJOqMqqyKL9FccASB9O0KwACQJpFTUBLTYOVvVU="
	  crossorigin="anonymous"></script>
	<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
	<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
	<title>Alchemy World</title>
	</head>
	<body id="main">
		<div id="left">
			<div id="navigation">
				<div id="go-home"><button type="button" class="btn btn-info nav-btn" onClick="goHome();" onmouseover="setBorder(this);" onmouseout="cancelBorder(this);">Home</button></div>
				<button type="button" class="btn btn-danger nav-btn" onClick="clearAll()" onmouseover="setBorder(this);" onmouseout="cancelBorder(this);">Clear</button>
				<button type="button" class="btn btn-dark nav-btn" onClick="openEncyclopedia();" data-toggle="modal" data-target="#encyclopediaModal" onmouseover="setBorder(this);" onmouseout="cancelBorder(this);">Encyclopedia <span class="badge badge-info" style="font-family:'Times New Romans'" id="encyclopedia-num"></span></button>
				<button type="button" class="btn btn-dark nav-btn" data-toggle="modal" data-target="#hintModal" onClick="showHint();" onmouseover="setBorder(this);" onmouseout="cancelBorder(this);">Hints</button>
				<button type="button" class="btn btn-dark nav-btn" data-toggle="modal" onClick="showGuide();" onmouseover="setBorder(this);" onmouseout="cancelBorder(this);">Guide</button>
			</div>
			<div id="combination">
				<div id="square1" onClick="removeElement(this.id, 1);"></div>
				<div><img src="../images/plus.jpg" height="100px" width="100px" id="plus" ></div>
				<div id="square2" onClick="removeElement(this.id, 2);"></div>
			</div>
			<div id="equal"><img src="../images/equal.png" height="100px" width="100px" ></div>
			<div id="square3"></div>
			<div id="combineBtn"><button type="button" class="btn btn-info nav-btn" onClick="combine();" data-toggle="modal" onmouseover="setBorder(this);" onmouseout="cancelBorder(this);">Combine!</button></div>
			<h1 id="Found-number" style="font-family:'Times New Roman', Times, serif; color:#FAA620;"><b>
				Found: <span id="num_found">
					<?php
						include('database.php');
						$sql = "SELECT count(*) FROM elements WHERE Found='Yes'";
						$result = $conn->query($sql);
						
						if($result->num_rows > 0) {
							while($row = $result->fetch_assoc()) {
								echo $row['count(*)']."</span>";
							}
						}
						
						$sql = "SELECT count(*) FROM elements";
						$result = $conn->query($sql);
						
						if($result->num_rows > 0) {
							while($row = $result->fetch_assoc()) {
								echo " / ".$row['count(*)'];
							}
						}
						
						mysqli_close($conn);
					?>
			</b></h1>
			
			<!--modal-->
			<div class="modal fade" id="messageModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
			  <div class="modal-dialog modal-dialog-centered" role="document">
				<div class="modal-content">
				  <div class="modal-header" style="background-color:FAA620">
					<h4 class="modal-title" id="messageTitle"></h4>
					<button type="button" class="close" data-dismiss="modal" aria-label="Close">
					  <span aria-hidden="true">&times;</span>
					</button>
				  </div>
				  <div class="modal-body" id="messageBody">
					
				  </div>
				  <div class="modal-footer" style="background-color:FAA620">
					<button type="button" class="btn btn-secondary" data-dismiss="modal" >Close</button>
				  </div>
				</div>
			  </div>
			</div>
			
			<!--modal-->
			<div class="modal fade" id="encyclopediaModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true" >
			  <div class="modal-dialog modal-dialog-centered" role="document">
				<div class="modal-content" >
				  <div class="modal-header" style="background-color:#FAA620">
					<h4 class="modal-title" id="encyclopediaTitle">Encyclopedia</h4>
					<button type="button" class="close" data-dismiss="modal" aria-label="Close">
					  <span aria-hidden="true">&times;</span>
					</button>
				  </div>
				  <div class="modal-body" id="encyclopediaBody" style="background-color:#380028; height:450px; overflow:auto;">
					<input type="email" class="form-control" id="searchInput" aria-describedby="emailHelp" placeholder="Search element here..." onkeyup="searchElementsEncyclopedia(this.value);">
					<table id="element-list2">
						<col width="25%">
						<col width="75%">					
						<?php
							include("database.php");
							$sql = "SELECT id, Name, Image_Name FROM elements WHERE Found='Yes' ORDER BY Name";
							$result = $conn->query($sql);
							
							if($result->num_rows > 0) {
								while($row = $result->fetch_assoc()) {
									echo "<tr class='rightTable' id='".$row["Image_Name"]."' onClick='elementDetails(this.id, ".$row["id"].");'><td><img src='../images/".$row["Image_Name"].".png'></td><td class='element-name'>".$row["Name"]."</td></tr>";
								}
							}
							mysqli_close($conn);
						?>
					</table>
				  </div>
				  <div class="modal-footer" style="background-color:FAA620">
					<button type="button" class="btn btn-secondary" data-dismiss="modal" >Close</button>
				  </div>
				</div>
			  </div>
			</div>
			
			<!--modal-->
			<div class="modal fade" id="elementModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
			  <div class="modal-dialog modal-dialog-centered" role="document">
				<div class="modal-content">
				  <div class="modal-header" style="background-color:FAA620">
					<h4 class="modal-title" id="elementTitle"></h4>
					<button type="button" class="close" data-dismiss="modal" aria-label="Close">
					  <span aria-hidden="true">&times;</span>
					</button>
				  </div>
				  <div class="modal-body" id="elementBody" style="background-color:#380028;">
					
				  </div>
				  <div class="modal-footer" style="background-color:FAA620">
					<button type="button" class="btn btn-secondary" data-dismiss="modal" onClick="openEncyclopedia();">Close</button>
				  </div>
				</div>
			  </div>
			</div>
			
			<!--modal-->
			<div class="modal fade" id="hintModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
			  <div class="modal-dialog modal-dialog-centered" role="document">
				<div class="modal-content">
				  <div class="modal-header" style="background-color:FAA620">
					<h4 class="modal-title" id="hintTitle">Hints</h4>
					<button type="button" class="close" data-dismiss="modal" aria-label="Close">
					  <span aria-hidden="true">&times;</span>
					</button>
				  </div>
				  <div class="modal-body" id="hintBody" style="background-color:#380028;">
					
				  </div>
				  <div class="modal-footer" style="background-color:FAA620">
					<button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
				  </div>
				</div>
			  </div>
			</div>
			
			<!--modal-->
			<div class="modal fade" id="guideModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
			  <div class="modal-dialog modal-dialog-centered" role="document">
				<div class="modal-content">
				  <div class="modal-header" style="background-color:FAA620">
					<h4 class="modal-title" id="guideTitle">Guide</h4>
					<button type="button" class="close" data-dismiss="modal" aria-label="Close" onClick="stopVideo();">
					  <span aria-hidden="true">&times;</span>
					</button>
				  </div>
				  <div class="modal-body" id="guideBody" style="background-color:#380028; color:#FAA620; height:450px; overflow:auto;">
					<h5>How to play?</h5>
					<div style="text-align:center; margin-top:15px; margin-bottom:15px;">
					<video id="guideVideo" width="300px">
						<source src="../videos/guide.MP4" type="video/mp4" />
					</video>
					</div>
					<div style="text-align:justify; text-indent:50px;">The game is simple. You just need to choose <b>2</b> elements simply by clicking them from the list at your left hand side and Press <b>Combine!</b>.
					<br/>
					<br/>
					</div>
					<div style="text-align:justify; text-indent:50px;">
					In order to remove the selected elements, you can press <b>Clear</b> or just simply remove any one of them by clicking <b>the element in the square box</b>.
					</div>
					<h5 style="margin-top:30px;">Encyclopedia</h5>
					<div style="text-align:center; margin-top:15px; margin-bottom:15px;">
						<img src="../images/encyclopedia.png" width="150px" height="200px" style="border:1px white solid;">
					</div>
					<div style="text-align:justify;">
					The <b>Encyclopedia</b> will shows you the details of the elements you found.
					</div>
					<h5 style="margin-top:30px;">Hints</h5>
					<div style="text-align:center; margin-top:15px; margin-bottom:15px;">
						<img src="../images/hintbutton.png">
						<img src="../images/hint.png" width="250px" height="150px" style="border:1px white solid;">
					</div>
					<div style="text-align:justify;">
					If you ever get stuck in the game, just simply press the <b>Hints</b> button to get a new idea.
					</div>
				  </div>
				  <div class="modal-footer" style="background-color:FAA620">
					<button type="button" class="btn btn-secondary" data-dismiss="modal" onClick="stopVideo();">Close</button>
				  </div>
				</div>
			  </div>
			</div>
		</div>
		<div id="right">
			<input type="email" class="form-control" id="searchInput" aria-describedby="emailHelp" placeholder="Search element here..." onkeyup="searchElements(this.value);">
			<table id="element-list">
				<col width="25%">
				<col width="75%">
				<?php
					include("database.php");
					$sql = "SELECT id, Name, Image_Name FROM elements WHERE Found='Yes' ORDER BY Name";
					$result = $conn->query($sql);
					
					if($result->num_rows > 0) {
						while($row = $result->fetch_assoc()) {
							echo "<tr class='rightTable' id='".$row["Image_Name"]."' onClick='putElement(this.id, ".$row["id"].");' onmouseover='setBorderBottom(this);' onmouseout='cancelBorderBottom(this);'><td><img src='../images/".$row["Image_Name"].".png'></td><td class='element-name'>".$row["Name"]."</td></tr>";
						}
					}
					mysqli_close($conn);
				?>
			</table>
		</div>
	</body>
	<script>
		var square1 = 0;
		var square2 = 0;
		var square3 = 0;
		var encyclopediaNum = 0;
		
		function putElement(id, elementId){
			if(square1==0){
				var div = document.getElementById('square1');
				div.innerHTML += '<img src="../images/'+id+'.png" height="96px" width="96px" id="'+elementId+'">';
				square1 = 1;
			}
			else if(square2==0){
				var div = document.getElementById('square2');
				div.innerHTML += '<img src="../images/'+id+'.png" height="96px" width="96px" id="'+elementId+'">';
				square2 = 1;
			}
		}
		
		function clearAll(){
			if(square1==1){
				document.getElementById('square1').removeChild(document.getElementById('square1').childNodes[0]);
				square1 = 0;
			}
			if(square2==1){
				document.getElementById('square2').removeChild(document.getElementById('square2').childNodes[0]);
				square2 = 0;
			}
			if(square3==1){
				document.getElementById('square3').removeChild(document.getElementById('square3').childNodes[0]);
				square3 = 0;
			}
		}
		
		function removeElement(id, which){
				if(which==1 && square1==1){
					var div = document.getElementById(id);
					div.removeChild(div.childNodes[0]);
					square1 = 0;
				} else if(which==2 && square2==1){
					var div = document.getElementById(id);
					div.removeChild(div.childNodes[0]);
					square2 = 0;
				}
		}
		
		function combine(){
			if(square3==1){
				document.getElementById('square3').removeChild(document.getElementById('square3').childNodes[0]);
				square3 = 0;	
			}
			
			var outputSquare = document.getElementById('square3');
			var element1 = document.getElementById('square1');
			var element2 = document.getElementById('square2');
			try{
				var element1Id = element1.childNodes[0].id.toString();
				var element2Id = element2.childNodes[0].id.toString();
				$.post('getFinalElement.php', {postElement1:element1Id, postElement2: element2Id}, function(data){
					var obj = JSON.parse(data);
					console.log(obj);
					if(obj[0]!="none"){				
						outputSquare.innerHTML += '<img src="../images/'+obj[0]+'.png" height="96px" width="96px">';
						square3 = 1;
						
						$('#messageModal').modal('show');
						
						if(obj[3]=="No"){
							encyclopediaNum++;
							document.getElementById('encyclopedia-num').innerHTML = encyclopediaNum;
							document.getElementById('messageTitle').innerHTML = "New Element - "+obj[1];
							document.getElementById('messageBody').innerHTML = "<div style='text-align:center;'><img src='../images/"+obj[0]+".png' height='100px' width='100px'></div><h5>Description: </h5>"+obj[2];
							$("#element-list tbody").append("<tr class='rightTable' id='"+obj[0]+"' onClick='putElement(this.id, "+obj[4 ]+");' onmouseover='setBorderBottom(this);' onmouseout='cancelBorderBottom(this);'><td><img src='../images/"+obj[0]+".png'></td><td class='element-name'>"+obj[1]+"</td></tr>");
							$("#element-list2 tbody").append("<tr class='rightTable' id='"+obj[0]+"' onClick='elementDetails(this.id, "+obj[4]+");'><td><img src='../images/"+obj[0]+".png'></td><td class='element-name'>"+obj[1]+"</td></tr>");
							document.getElementById('num_found').innerHTML = obj[5];
						}
						else{
							document.getElementById('messageTitle').innerHTML = "Existing Element - "+obj[1];
							document.getElementById('messageBody').innerHTML = "This element has been found already!";
						}
					}
					else {
						$('#messageModal').modal('show');
						document.getElementById('messageTitle').innerHTML = "No Element";
						document.getElementById('messageBody').innerHTML = "No Element can be obtained with this combination.";
					}
				});
			}catch(err){
				$('#messageModal').modal('show');
				document.getElementById('messageTitle').innerHTML = "Not Enough Element";
				document.getElementById('messageBody').innerHTML = "Not enough element to combine! Please select at least 2 elements and try again.";
				console.log("No enough element to combine!");
			}
			
			document.getElementById('messageBody').style.backgroundColor = "#380028";
			document.getElementById('messageBody').style.color = "#FAA620";
		}
		
		function openEncyclopedia(){
			$('#encyclopediaModal').modal('show');
			encyclopediaNum = 0;
			document.getElementById('encyclopedia-num').innerHTML = "";
		}
		
		function elementDetails(id, elementId){
			$('#elementModal').modal({backdrop:'static', keyboard:false});
			$('#elementModal').modal('show');
			$('#encyclopediaModal').modal('hide');
			$.post('getElementDetails.php', {postElement:elementId}, function(data){
				var obj = JSON.parse(data);
				console.log(obj);
				document.getElementById('elementTitle').innerHTML = "Element - "+obj[0];
				document.getElementById('elementBody').innerHTML = "<div style='text-align:center;'><img src='../images/"+obj[2]+".png' height='100px' width='100px'></div><h5>Description: </h5>"+obj[1];
				if(obj[3]!=""){
					document.getElementById('elementBody').innerHTML += "<h5 id='combinationHeader'>Combinations: </h5><div style='text-align:center;'><img src='../images/"+obj[3]+".png' height='100px' width='100px'><img src='../images/plus.jpg' height='80px' width='80px' id='plusEncyclopedia' ><img src='../images/"+obj[4]+".png' height='100px' width='100px'></div>";
					document.getElementById('combinationHeader').style.marginTop = "20px";
					document.getElementById('plusEncyclopedia').style.marginLeft = "30px";
					document.getElementById('plusEncyclopedia').style.marginRight = "30px";
				}
				document.getElementById('elementBody').style.color = "#FAA620";
			});
		}
		
		function showHint(){
			$.post('getHint.php', function(data){
				var obj = JSON.parse(data);
				console.log(obj);
				if(obj[0]!=""){
					document.getElementById('hintBody').innerHTML = "<h5>Try combining these two: </h5><div style='text-align:center;'><img src='../images/"+obj[1]+".png' height='100px' width='100px'><img src='../images/plus.jpg' height='80px' width='80px' id='plusEncyclopedia' ><img src='../images/"+obj[2]+".png' height='100px' width='100px'></div>";
					document.getElementById('plusEncyclopedia').style.marginLeft = "30px";
					document.getElementById('plusEncyclopedia').style.marginRight = "30px";
				}
				else{
					document.getElementById('hintBody').innerHTML = "<h5>No hint: </h5>You have found all the elements. Good job! Please wait for the next update to come.";
				}
				document.getElementById('hintBody').style.color = "#FAA620";
			});
		}
		
		function showGuide(){
			$('#guideModal').modal({backdrop:'static', keyboard:false});
			$('#guideModal').modal('show');
			var vid = document.getElementById('guideVideo');
			vid.play();
		}
		
		function stopVideo(){
			var vid = document.getElementById('guideVideo');
			vid.pause();
			vid.currentTime = 0;
		}
		
		function searchElements(text){
			$.post('getSearchElements.php', {postText:text}, function(data){
				var obj = JSON.parse(data);
				if(obj.length==0){
					console.log("Nothing");
					$("#element-list tbody").empty();
				}
				else{
					console.log(obj);
					$("#element-list tbody").empty();
					for(var i = 0;i<obj.length;i=i+3) {
						$("#element-list tbody").append("<tr class='rightTable' id='"+obj[i+2]+"' onClick='putElement(this.id, "+obj[i]+");' onmouseover='setBorderBottom(this);' onmouseout='cancelBorderBottom(this);'><td><img src='../images/"+obj[i+2]+".png'></td><td class='element-name'>"+obj[i+1]+"</td></tr>");
					}
				}				
			});
		}
		
		function searchElementsEncyclopedia(text){
			$.post('getSearchElements.php', {postText:text}, function(data){
				var obj = JSON.parse(data);
				if(obj.length==0){
					console.log("Nothing");
					$("#element-list2 tbody").empty();
				}
				else{
					console.log(obj);
					$("#element-list2 tbody").empty();
					for(var i = 0;i<obj.length;i=i+3) {
						$("#element-list2 tbody").append("<tr class='rightTable' id='"+obj[i+2]+"' onClick='elementDetails(this.id, "+obj[i]+");'><td><img src='../images/"+obj[i+2]+".png'></td><td class='element-name'>"+obj[i+1]+"</td></tr>");
					}
				}				
			});
		}
		
		function setBorder(elem){
			elem.style.border = "2px gray solid";
		}
		
		function cancelBorder(elem) {
			elem.style.border = "0";
		}
		
		function setBorderBottom(elem){
			elem.style.borderTop = "3px gray solid";
			elem.style.borderBottom = "3px gray solid";
		}
		
		function cancelBorderBottom(elem) {
			elem.style.border = "0";
		}
		
		function goHome() {
			window.location.href = "../index.html";
		}
	</script>
	<link rel="stylesheet" type="text/css" href="../css/style.css">
</html>