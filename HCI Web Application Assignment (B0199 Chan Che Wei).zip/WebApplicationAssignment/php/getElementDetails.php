<?php
	include('database.php');
	$element = $_POST['postElement'];
	$name = "";
	$description = "";
	$image_name = "";
	$element1_ID = "";
	$element2_ID = "";
	
	$sql = "SELECT Name, Description, Image_name from elements WHERE ID='".$element."';";
	$result = $conn->query($sql);
	
	if($result->num_rows > 0) {
		while($row = $result->fetch_assoc()) {
			$name = $row['Name'];
			$description = $row['Description'];
			$image_name = $row['Image_name'];
		}
	}
	
	$sql = "SELECT Image_name FROM elements INNER JOIN combinations ON elements.ID = combinations.Element1_ID WHERE Final_ID='".$element."';";
	
	$result = $conn->query($sql);
	
	if($result->num_rows > 0) {
		while($row = $result->fetch_assoc()) {
			$element1_ID = $row['Image_name'];
		}
	}
	
	$sql = "SELECT Image_name FROM elements INNER JOIN combinations ON elements.ID = combinations.Element2_ID WHERE Final_ID='".$element."';";
	
	$result = $conn->query($sql);
	
	if($result->num_rows > 0) {
		while($row = $result->fetch_assoc()) {
			$element2_ID = $row['Image_name'];
		}
	}
	
	echo json_encode(array($name, $description, $image_name, $element1_ID, $element2_ID));
?>