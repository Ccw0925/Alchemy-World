<?php
	include('database.php');
	$text = $_POST['postText'];
	$id = "";
	$name = "";
	$image_name = "";
	$a = array();
	
	$sql = "SELECT id, name, Image_name from elements WHERE name LIKE '%".$text."%' AND Found='Yes' ORDER BY name;";
	$result = $conn->query($sql);
	
	if($result->num_rows > 0) {
		while($row = $result->fetch_assoc()) {
			$id = $row['id'];
			$name = $row['name'];
			$image_name = $row['Image_name'];
			array_push($a, $id, $name, $image_name);
		}
	}
	
	echo json_encode($a);
?>